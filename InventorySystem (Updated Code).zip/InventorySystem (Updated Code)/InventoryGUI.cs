using System.Windows.Forms.VisualStyles;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace InventorySystem
{
    public partial class InventoryGUI : Form
    {
        // Instantiated the InventoryManager class to manage inventory items
        private Inventory inventory = new Inventory();
        private InventoryManager inventoryManager = new InventoryManager();
        public InventoryGUI()
        {
            InitializeComponent();
        }

        private void licensingInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Program Icons from: Flaticon.com. Free for personal and commercial purpose with attribution. Thanks!\n\nDo not redistribute this Inventory Application for pay. This application has been made by students as a C# exercise at MNSU, Mankato", "Licensing Information");
        }

        private void aboutOurProjectToolStripMenuItem_Click_3(object sender, EventArgs e)
        {
            MessageBox.Show("This project has been made by:\nCollin Frame\nSemaj Sirrom\nQai Hussey\nZeynel Karagoz\nPriscilla Tray\n\nAt Minnesota State University, Mankato For CIS 122: Data Structures!", "About The Team!");
        }
        private void resetDatabaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("this would reset the csv file/create it but i am not doing all that rn", "Database Reset Success!");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddToInventory A2I = new AddToInventory();
            A2I.ShowDialog();
            // Gets the values from the input fields to create a new item
            string name = itemNameTextBox.Text;
            string sku = itemSkuTextBox.Text;
            string status = itemStatusComboBox.Text;

            InventoryItem newItem = new InventoryItem(name, sku, status);
            inventory.AddToInventory(newItem); // Use Inventory class to add the item

            // Update the DataGridView to reflect the new item
            UpdateInventoryDisplay();
        }
        private void InventoryGUI_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void InventoryGUI_Activated(object sender, EventArgs e)
        {
            // This method SHOULD be used to UPADTE our table with our new data assuming that the user left/came back after modifying it.
            // Get values from input fields to update an existing item
            int id = int.Parse(idTextBox.Text);
            string? newName = nameTextBox.Text;
            string? newSku = skuTextBox.Text;
            string? newStatus = statusTextBox.Text;

            // Update the specified fields of the item
            inventoryManager.Modify(id, newStatus, newName, newSku);

            UpdateInventoryDisplay(); // Refresh the DataGridView 
        }






        private void button2_Click(object sender, EventArgs e)
        {
            RemoveFromInventory RFI = new RemoveFromInventory();
            RFI.ShowDialog();
             // Gets SKU from the input field for the item to be removed
            string sku = skuRemoveTextBox.Text;
            inventoryManager.stock.RemoveFromInventory(sku);

            UpdateInventoryDisplay(); // Refresh the DataGridView */
        }

        private void button3_Click(object sender, EventArgs e)
        {
            EditCurrentINV EINV = new EditCurrentINV();
            EINV.ShowDialog();

            inventoryDataGridView.Rows.Clear(); // Clear Existing Rows

            // Add each item in the inventory to the DataGridView
            foreach (var item in inventoryManager.stock.GetList())
            {
                inventoryDataGridView.Rows.Add(item.ID, item.Name, item.SKU, item.Status);
            }
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SearchINV SINV = new SearchINV();
            SINV.ShowDialog();

            string sku = skuSearchTextBox.Text;
            InventoryItem item = inventoryManager.FindItemBySku(sku);

            // Display the item information if found, otherwise show a "not-found" message
            if (item != null)
            {
                MessageBox.Show($"Item found: Name: {item.Name}, ID: {item.ID}, Status: {item.Status}");
            }
            else
            {
                MessageBox.Show("Item not found.");
            }
        }

    }
    private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) // Inventory
    {
        if (e.RowIndex >= 0) // Make sure that a valid row is selected
        {
            // Get the selected row
            DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

            // Populate the form fields with the data from the selected row
            // So it can be edited or displayed
            textBoxName.Text = selectedRow.Cells["Name"].Value.ToString();
            textBoxSKU.Text = selectedRow.Cells["SKU"].Value.ToString();
            textBoxQuantity.Text = selectedRow.Cells["Quantity"].Value.ToString();
            comboBoxStatus.SelectedItem = selectedRow.Cells["Status"].Value.ToString();
        }
    }
    private void UpdateInventoryDisplay()
    {
        // Logic to update the inventory display in the GUI
        inventoryDataGridView.Rows.Clear();

        // Add updated inventory items to the DataGridView
        foreach (var item in inventoryManager.stock.GetList())
        {
            inventoryDataGridView.Rows.Add(item.ID, item.Name, item.SKU, item.Status);
        }
    }
    // Placeholder classes for Inventory, InventoryManager, and InventoryItem
    public class Inventory
    {
        public void AddToInventory(InventoryItem item) { /* Add logic */ }
    }

    public class InventoryManager
    {
        public Stock stock = new Stock(); // Assuming Stock is a class
        public void Modify(int id, string status, string name, string sku) { /* Add logic */ }
        public InventoryItem FindItemBySku(string sku) => null; // Add logic
    }

    public class InventoryItem
    {
    public int ID { get; set; }
    public string Name { get; set; }
    public string SKU { get; set; }
    public string Status { get; set; }

    public InventoryItem(string name, string sku, string status) { Name = name; SKU = sku; Status = status; }
    }

    public class Stock
    {
    public void RemoveFromInventory(string sku) { /* Add logic */ }
    public System.Collections.Generic.List<InventoryItem> GetList() => new System.Collections.Generic.List<InventoryItem>();
    }

}
