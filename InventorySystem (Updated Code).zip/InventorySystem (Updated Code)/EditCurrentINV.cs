﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventorySystem
{
    public partial class EditCurrentINV : Form
    {
        public EditCurrentINV()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != "")
            {
                if (textBox3.Text.All(char.IsDigit))
                {
                    EditSpecific EDS = new EditSpecific(1, textBox3.Text);
                    EDS.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Must be a Numeric ID");
                }
      
            
            }
            else
            {
                MessageBox.Show("You must enter a value for the item ID.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if (textBox2.Text != "")
                {
                    MessageBox.Show("Please only have one of the two fields filled out.");
                }
                else
                {
                    EditSpecific EDSNAME = new EditSpecific(2, textBox1.Text);
                    EDSNAME.ShowDialog();
                }
            }
            else if (textBox2.Text != "") // SKU needs numeric validation
            {
                if (textBox2.Text.All(char.IsDigit))
                {
                    EditSpecific EDSNAME = new EditSpecific(3, textBox2.Text);
                    EDSNAME.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Must be a Numeric ID");
                }
            }
            else
            {
                MessageBox.Show("You must fill out one of the two fields.");
            }
        }
    }
}
