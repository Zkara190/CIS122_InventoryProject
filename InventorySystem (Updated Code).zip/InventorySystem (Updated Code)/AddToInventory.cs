﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventorySystem
{
    public partial class AddToInventory : Form
    {
        public AddToInventory()
        {
            InitializeComponent();
        }

        private void AddToInventory_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }

        private void AddToInventory_Enter(object sender, EventArgs e)
        {

        }

        private void AddToInventory_Activated(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "secret")
            {
                Font = new Font(new FontFamily("Comic Sans MS"), 16f);
                this.MaximumSize = new Size(571, 378);
                this.MinimumSize = new Size(571, 378);
                this.Size = new Size(571, 378);
                label1.Text = "Congrats! You found it...";
                label1.Font = Font;
                label2.Text = "you are officially the best hackerman";
                label2.Font = Font;
                string uri = "https://www.youtube.com/embed/7YZCUpnaTfg?&autoplay=1&mute=0";
                System.Diagnostics.Process.Start("explorer.exe", $"\"{uri}\"");
                this.Text = "Easter Egg";
                label3.Hide();
                label4.Hide();
                label5.Hide();
                button1.Hide();
                textBox1.Hide();
                textBox2.Hide();
                textBox3.Hide();
                comboBox1.Hide();
            }
            else if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && comboBox1.Text != "")
            {
                MessageBox.Show("This would add to the database");
            }
            else
            {
                MessageBox.Show("You must fill out all 4 fields to add an item.");
            }
        }
    }
}
